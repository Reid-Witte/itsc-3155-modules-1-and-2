#Reid Witte
#using w3schools as a reference

num = int(input("Enter an integer greater than 1: "))

for x in range(num+1):
    print("The cube of " + str(x) + " is " + str(x*x*x))
    
